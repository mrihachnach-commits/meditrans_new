---
name: pdf-translation-layout
description: "Translate and redesign existing PDFs while preserving typography, inline emphasis, page layout, colors, figures, and visual hierarchy. Use for localized PDFs, especially when the source includes rich formatting or brand-specific layouts."
---
Kích hoạt kỹ năng khi gõ lệnh /translate
# Quy trình dịch và dàn trang PDF giữ định dạng

Áp dụng khi cần thay ngôn ngữ trong PDF nhưng vẫn giữ phong cách thiết kế của bản gốc. Không flatten toàn trang thành ảnh để làm bản giao cuối; ưu tiên giữ văn bản có thể tìm kiếm, sao chép và truy cập.

## Quy trình bắt buộc

1. **Kiểm kê PDF nguồn**
   - Ghi số trang, kích thước trang, độ phân giải hình, số lớp văn bản và metadata.
   - Dùng `pdffonts` để liệt kê font, kiểu, nhúng hay chưa nhúng, encoding và subset.
   - Trích xuất text theo span/character, không chỉ paragraph thuần. Lưu cho mỗi span: trang, tọa độ bbox, font name, cỡ chữ, màu, bold/italic, underline/strike, baseline, hướng đọc, khoảng cách dòng và liên kết nếu có.
   - Render ảnh tham chiếu từng trang để nhận diện ảnh minh họa, biểu đồ, nền màu, cột và phân cấp. Giữ nguyên asset vector/ảnh gốc.

2. **Chuẩn hóa nội dung dịch**
   - Tạo bảng thuật ngữ trước khi dịch; khóa cách dịch và cách giữ từ tiếng Anh.
   - Lưu cấu trúc nội dung có đánh dấu ngữ nghĩa (heading, paragraph, label, caption, bullet) và style gốc riêng biệt. Không làm mất thông tin format khi chuyển sang chuỗi dịch.
   - Dịch theo ngữ cảnh, sau đó rà ngữ nghĩa, số liệu, tên riêng, thuật ngữ và dấu tiếng Việt.
   - Gắn mỗi đoạn dịch về khối nguồn tương ứng; không gộp hoặc đảo khối khiến sai trình tự đọc.

3. **Lập bản đồ style và bố cục**
   - Giữ bảng ánh xạ `source style → target style`: family/font, size, weight, italic, underline, color, leading, alignment, indents, spacing before/after, character spacing.
   - Bảo toàn heading hierarchy và tương quan cỡ chữ; không ép mọi đoạn về một font/cỡ chung.
   - Bảo toàn bold/italic/underline theo đúng phạm vi ký tự, nhất là nhãn như **Individual tasks**, **Team workflows**, **Department KPIs** và **Core business processes**.
   - Tăng giãn dòng nhẹ so với bản gốc: mặc định khoảng +1 pt leading (hoặc tương đương khoảng 5–8% khi giới hạn bố cục), trừ khi gây tràn; ghi nhận ngoại lệ.
   - Đặt paragraph alignment là **justify** cho văn xuôi nếu source cũng là văn xuôi hai lề; không justify tiêu đề, nhãn, mục lục, caption hoặc dòng ngắn. Tránh khoảng trắng chữ bất thường ở dòng cuối.

4. **Chọn và nhúng font**
   - Ưu tiên đúng font gốc được nhúng trong PDF. Trường hợp PDF subset font, kiểm tra quyền sử dụng và khả năng lấy bản đầy đủ hợp pháp trước khi thay thế.
   - Chỉ dùng Anthropic/MOMO font khi người dùng cung cấp hoặc có nguồn tải được phép và license cho phép nhúng. Không giả định font độc quyền sẵn có.
   - Nếu không có font gốc, chọn fallback có metric, x-height và sắc thái gần nhất, hỗ trợ đầy đủ tiếng Việt; ghi rõ đó là font thay thế và xin duyệt khi độ trung thực thương hiệu là yêu cầu trọng yếu.
   - Nhúng font vào PDF đầu ra; kiểm tra glyph tiếng Việt, dấu tổ hợp, bold/italic thật (không faux style), và hiển thị trên ít nhất hai trình đọc PDF.

5. **Dàn lại từng trang**
   - Tái sử dụng nền, hình, biểu đồ, icon và đường vector gốc; chỉnh sửa từng khối text trong tọa độ gốc. Không phủ một hình chữ nhật màu ước lượng lên nền.
   - Khi cần che chữ cũ, lấy màu từ chính vùng nền hoặc tái tạo nền/gradient/texture bằng asset gốc; kiểm tra không tạo viền, mảng màu lệch hay mất đồ họa.
   - Giữ kích thước trang, lề, cột, khoảng cách giữa khối. Để câu tiếng Việt tràn sang dòng mới tự nhiên; ưu tiên nới vùng text hoặc điều chỉnh leading nhỏ trước khi giảm cỡ chữ.
   - Không tự ý giảm font quá mức để nhồi nội dung. Nếu bản dịch không vừa: rút gọn câu mà không mất nghĩa, điều chỉnh ngắt dòng/khung chữ, rồi mới giảm cỡ nhẹ và ghi nhận.
   - Xác định **safe zone** riêng cho từng trang từ lề/khung nội dung của PDF nguồn. Nếu không xác định được, giữ tối thiểu padding 4% kích thước trang ở cả bốn cạnh; dùng mức lớn hơn giữa padding này và lề nội dung gốc. Không để glyph, dấu tiếng Việt, stroke, shadow, logo hoặc số trang vượt khỏi safe zone hay bleed/trim box.
   - Đo độ rộng và chiều cao thực của text bằng đúng font, cỡ chữ và style sẽ nhúng; không suy ra từ độ dài chuỗi hoặc bbox của font khác. Tính cả dấu tổ hợp, ascent/descent và stroke. Nếu heading không vừa một dòng, chủ động ngắt dòng theo cụm nghĩa trong khung heading trước khi giảm cỡ; không thu nhỏ/scale ngang gây méo chữ.
   - Với mọi khối, đặt padding trong (inset) rõ ràng ở bốn cạnh. Ngắt dòng theo từ; không tách dấu/ký tự tiếng Việt, không để từ đơn hoặc dòng cuối rơi vào lề, và không justify dòng cuối. Giữ tối thiểu 2–4 pt giữa glyph cuối và mép khung, cộng thêm phần an toàn cho dấu/descender; với heading lớn dùng inset tương ứng ít nhất một cap-height nhỏ hoặc 4% khung.
   - Trước khi xuất, kiểm tra tự động bbox từng dòng/span sau dàn: `text_bbox ⊆ text_frame_inset ⊆ page_safe_zone`. Nếu không đạt, báo overflow và sửa ngắt dòng/khung/leading; chỉ xuất khi tất cả lỗi tràn, clip, va chạm và sát mép đều bằng 0. Không dùng clip hoặc cắt mép để che lỗi.
   - Với trang có infographic/visualization, giữ nguyên đồ họa và thay nhãn bên trong theo đúng vị trí, ngôn ngữ và cấp độ; bảo toàn biểu tượng, màu từng bước, thang đo và thứ tự tiến triển. Với trang mở chương, giữ nhãn chương, hình minh họa, heading lớn và tỉ lệ các cấp heading.
   - Với pill/capsule/badge, lấy bbox của outline gốc; căn tâm nhãn dịch bằng advance width của đúng font đích so với tâm capsule, và khớp baseline với dòng nguồn. Không tái sử dụng tọa độ trái/baseline nguồn một cách máy móc khi độ rộng/font thay đổi. Mọi miếng che phải nằm hoàn toàn trong ruột capsule và dùng đúng màu nền của chính trang (đặc biệt trang mở chương); không che outline hoặc để lại mảng trắng.
   - Bảo toàn phân trang tham chiếu trong mục lục; nếu phân trang thay đổi ở cả tài liệu, cập nhật mục lục sau khi hoàn tất toàn bộ.

6. **Kiểm định theo trang**
   - Render PDF đầu ra ở cùng kích thước và độ phân giải với bản tham chiếu; so sánh song song hoặc overlay.
   - Kiểm tra nội dung thiếu/thừa; font và style; cỡ chữ heading; leading; justify; clipping/tràn; chồng lấn; dấu tiếng Việt; infographic; màu nền; vùng vá; số trang; khả năng tìm kiếm/copy; font embedding.
   - Rà riêng bốn mép từng trang ở 100% và mức phóng đại: không có chữ/dấu chạm hoặc vượt safe zone; heading không bị cụt; khung/cột có padding đều; justify không kéo giãn bất thường. Lưu kết quả kiểm tra overflow theo trang và chặn phát hành nếu còn bất kỳ lỗi nào.
   - Với màu thương hiệu, lấy giá trị từ pixel/vector/asset gốc chứ không đoán bằng mắt. Mọi vùng che phải hòa nền ở 100% và khi phóng to.
   - Với badge, kiểm tra số đo `center(target text)` so với `center(source outline)` và chênh baseline/span bbox; xác nhận fill patch trùng màu nền chương, outline còn nguyên, không có seam/ô trắng. Kiểm tra tất cả trang mở chương và các trang nội dung lặp lại badge.
   - Trích xuất text từ PDF cuối và đối chiếu với bản dịch đã duyệt; so sánh danh sách font đầu ra; xác nhận trang không bị raster hóa toàn bộ ngoài các ảnh/đồ họa vốn raster.
   - Không tuyên bố “giữ nguyên chính xác” nếu còn font thay thế, ảnh hóa, mất text layer, hoặc khác biệt căn chỉnh. Nêu rõ sai khác còn lại.

7. **Duyệt và phát hành theo đợt**
   - Với dự án dài, làm 3–5 trang mẫu gồm bìa, mục lục, trang văn xuôi, trang mở chương và trang có bảng/infographic.
   - Gửi PDF mẫu và danh sách quyết định typography/font/thuật ngữ để người dùng duyệt trước khi nhân rộng.
   - Chỉ sau khi được duyệt mới chạy phần còn lại; giữ bản gốc bất biến và lưu bản đầu ra theo phiên bản.
   - Bàn giao PDF cuối, bảng thuật ngữ, ghi chú font/fallback và checklist QA; nếu được yêu cầu, bàn giao thêm PDF có text layer hoặc file nguồn dàn trang.

## Runbook triển khai

Khi thực hiện dự án nhiều trang hoặc cần quy trình có thể lặp lại, đọc [`references/production-runbook.md`](references/production-runbook.md). Runbook quy định kiểm kê nguồn, dịch theo page/block và glossary chung, đo font/line-wrap, bảo toàn artwork và hyperlink theo từng cột, kiểm định cơ khí/hình học/nội dung/trực quan, và hồ sơ bàn giao. Dùng checklist ở runbook sau mỗi lần sửa để tránh tái diễn lỗi badge bị phủ viền, heading lấn cột, khoảng trắng text layer bị mất và URI gắn nhầm.

## Hồ sơ cần lưu cho mỗi dự án

- PDF nguồn bất biến và metadata.
- Bảng thuật ngữ đã duyệt.
- Bản dịch có cấu trúc theo trang/khối.
- Bảng style/font mapping; báo cáo font được nhúng hoặc thay thế.
- Ghi chú đồ họa, màu nền, xử lý ngoại lệ.
- Checklist kiểm tra từng trang và danh sách lỗi đã xử lý.
