# Runbook sản xuất PDF dịch giữ bố cục

Dùng runbook này cùng `SKILL.md` khi thực hiện dự án thực tế. Giữ nguyên file nguồn; làm việc trên bản sao và ghi rõ phạm vi trang cần bàn giao.

## A. Khởi tạo và kiểm kê

1. Tải PDF nguồn vào workspace dự án; lưu URL nguồn, tên file, ngày nhận, checksum và bản gốc không chỉnh sửa.
2. Xác nhận **số trang thực tế** và kích thước trang bằng `pdfinfo`; không giả định tài liệu có trang mang số cao nhất được người dùng nhắc đến. Ghi rõ phạm vi bàn giao.
3. Kiểm tra font, encoding, subset, embedding, ảnh, vector và annotation bằng `pdffonts`, `pdfimages -list` và PDF parser.
4. Trích xuất text có cấu trúc theo trang/khối/dòng/span. Lưu bbox, baseline, font, cỡ, màu, weight, style và reading order; ghi riêng hình, bảng, link, footer và page number.
5. Render toàn bộ trang làm montage; render riêng các trang nhiều cột, trang mở chương, bảng/infographic và trang tài nguyên ở độ phân giải đọc được.

## B. Dịch và khóa thuật ngữ

1. Tạo glossary trước khi dịch. Mỗi mục có: thuật ngữ nguồn, bản dịch ưu tiên, khi nào giữ tiếng Anh, ví dụ ngữ cảnh và các biến thể không chấp nhận.
2. Bảo toàn cấu trúc theo page/block; đánh dấu title, section heading, subheading, paragraph, callout, label, caption, CTA, hyperlink và inline emphasis.
3. Chia việc dịch theo trang hoặc nhóm trang có ranh giới rõ; cung cấp cùng glossary và ngữ cảnh liền kề cho mọi đơn vị dịch.
4. Sau khi ghép, rà nhất quán xuyên suốt tài liệu, đặc biệt thuật ngữ xuất hiện lần đầu, viết hoa agent/agents, tên sản phẩm, pháp nhân, số liệu, acronym và thuật ngữ buy-side.
5. Nếu đổi thuật ngữ đã khóa, sửa tất cả các trang liên quan rồi mới dàn lại.

## C. Quyết định font và typography

1. Thử dùng font gốc nếu PDF chứa đầy đủ glyph và license cho phép. Font subset/Type 3 không đồng nghĩa có thể tái sử dụng làm font tiếng Việt đầy đủ.
2. Nếu cần fallback, chọn font Unicode có cảm giác và metrics gần nguồn; dùng đúng family/weight cho heading, body, bold, italic và sans/serif. Nhúng font đầu ra.
3. Lập style map riêng theo vai trò. Đo từng dòng bằng đúng font/size/weight mục tiêu; tính ascent, descent, dấu tiếng Việt, leading và padding.
4. Giữ nhấn mạnh inline ở đúng cụm từ. Không làm mất định dạng khi chuyển block thành text; không giả lập bold/italic nếu có weight thật.
5. Với văn xuôi, justify chỉ các dòng đầy đủ; dòng cuối căn trái. Với tiêu đề, link ngắn, label, caption và CTA, dùng căn trái hoặc căn theo mẫu gốc.
6. Khi dựng text theo từng word-run để điều khiển justify, ghi khoảng trắng thật vào text object hoặc xác nhận text extraction khôi phục khoảng trắng; không chỉ dựa vào khoảng cách thị giác. Thử bằng `pdftotext`/`get_text()` và kiểm tra copy-paste.

## D. Dàn trang và xử lý hình

1. Giữ kích thước trang, nền, illustration, logo, vector, biểu đồ và thứ tự layer gốc khi có thể. Ưu tiên thay đúng vùng text thay vì phủ cả trang.
2. Trích màu từ vector hoặc pixel vùng nền; không đoán màu. Khi che chữ trong badge/capsule, chỉ phủ phần ruột bằng đúng màu nền trang, để lại stroke/viền; tránh hình chữ nhật vượt khỏi outline hoặc tạo mảng trắng.
3. Đo bbox outline gốc và baseline dòng nhãn. Căn nhãn dịch theo tâm capsule bằng advance width của font đích; không giữ nguyên tọa độ trái hoặc baseline cứng nếu độ rộng/font thay đổi. Nếu trang có nền màu, dùng màu đó cho miếng che trong ruột capsule.
4. Xác định safe zone theo nội dung nguồn. Nếu thiếu dữ liệu, dùng tối thiểu 4% kích thước trang ở cả bốn cạnh hoặc lề gốc lớn hơn. Với mọi text frame, đặt inset riêng và bảo đảm glyph nằm trọn trong frame inset.
5. Ngắt dòng theo từ và cụm nghĩa. Đo heading tiếng Việt trong đúng cột; nếu dài, wrap bên trong khung trước khi giảm size. Không để heading lấn sang cột kế, đè hình, link, footer hoặc CTA.
6. Nếu bản dịch dài hơn: nới khung trong giới hạn lưới, tinh chỉnh leading/paragraph gap có kiểm soát, rút gọn câu không mất ý, rồi mới giảm font nhẹ. Ghi lại ngoại lệ trên trang.
7. Với trang mở chương, giữ đúng màu nền, vị trí hình minh họa, nhãn chương, tỷ lệ heading và khoảng trắng. Với infographic, giữ artwork, palette, thứ tự tiến triển và đặt lại nhãn theo hình gốc.

## E. Bảo toàn hyperlink và reading order

1. Trước khi redaction hoặc thay chữ, lưu toàn bộ annotation: URI/action, bbox, page, text anchor gần nhất và reading order.
2. Ghép nhãn dịch với URI theo **cột rồi thứ tự đọc trong cột**; không sắp tất cả link toàn trang chỉ theo tọa độ Y nếu có nhiều cột.
3. Sau khi dàn lại, thêm annotation mới bao quanh chính xác nhãn dịch; nếu link là một phần CTA, chỉ gắn annotation vào cụm liên kết.
4. So sánh từng URI nguồn với URI đầu ra, đếm số link trên mỗi trang và thử mở link. Giữ nguyên link thương hiệu/URL khi được thiết kế chủ ý.
5. Vẽ underline theo độ rộng text thực, không ước lượng; kiểm tra không chạm heading, dòng kề hoặc mép cột.

## F. Kiểm định lặp theo vòng

Chạy các lượt theo thứ tự, sửa lỗi rồi chạy lại các phép kiểm liên quan:

1. **Cơ khí:** page count, page size, output file size, font embedding, text extraction, link count/URI, image/vector presence.
2. **Hình học:** bbox từng span/dòng trong safe zone; kiểm tra tràn ngang/dọc, margin, padding 4 cạnh, khoảng cách tới footer, cột và khung. Riêng badge, so tâm text với tâm outline và baseline nguồn; kiểm tra patch nền khớp màu, outline còn nguyên.
3. **Nội dung:** đối chiếu từng block với bản dịch đã duyệt; phát hiện text thiếu/thừa, English sót ngoài tên riêng/thuật ngữ được giữ, lỗi dấu và từ bị dính/mất khoảng trắng.
4. **Trực quan:** render montage toàn bộ; xem 100% tất cả trang và phóng đại các trang dày, mở chương, bảng/figure, capsule, trang tài nguyên/link và các trang từng báo lỗi. So sánh song song với nguồn; kiểm tra tất cả chapter dividers lẫn badge lặp ở trang nội dung.
5. **Lặp lại:** sau bất kỳ thay đổi font, text, leading, safe zone, overlay hoặc link, render lại trang bị ảnh hưởng và chạy lại text/bbox/link checks.
6. Chặn phát hành nếu còn lỗi tràn, clip, va chạm, viền trắng/màu vá lệch, link sai, dấu lỗi hoặc text extraction mất khoảng trắng.

## G. Bàn giao và hồ sơ

Bàn giao PDF cuối cùng có text layer tìm kiếm được; kèm glossary, source-to-target style map, ghi chú font/fallback, trạng thái hyperlink, checklist QA và danh sách ngoại lệ. Nêu rõ những gì đã giữ nguyên và những khác biệt còn lại; không mô tả là pixel-perfect nếu còn font thay thế hoặc tái dàn. Ghi checksum và lưu file đầu ra theo phiên bản.
